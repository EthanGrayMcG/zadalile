Thank you for purchasing, i wish you all the best with this item!

Please go through the DOCUMENTATION First.

We will be happy to help you solve any issues. If you have any questions, suggestions or ideas, please feel free to contact us anytime at (https://themeforest.net/user/exill)

Customer satisfaction is our highest priority!

Like this item?
Please rate this item 5 Stars (★★★★★) and leave your feedback at (http://themeforest.net/downloads)

This is very important for me, Thanks!
